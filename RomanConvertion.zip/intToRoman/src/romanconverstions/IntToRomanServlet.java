package romanconverstions;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/intToRomanServlet")
public class IntToRomanServlet extends HttpServlet {
	 
	protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
	      
		
			String value = request.getParameter("intValue");
			int num = Integer.parseInt(value);
			
			
			  StringBuilder sb = new StringBuilder();
			    int times = 0;
			    String[] romans = new String[] { "I", "IV", "V", "IX", "X", "XL", "L",
			            "XC", "C", "CD", "D", "CM", "M" };
			    int[] ints = new int[] { 1, 4, 5, 9, 10, 40, 50, 90, 100, 400, 500,
			            900, 1000 };
			    for (int i = ints.length - 1; i >= 0; i--) {
			        times = num / ints[i];
			        num %= ints[i];
			        while (times > 0) {
			            sb.append(romans[i]);
			            times--;
			        }
			    }
	        PrintWriter writer = response.getWriter();
	        
	        String htmlRespone = "<html>";
	        htmlRespone += "<h2>Equivalent Roman value is : " + sb.toString() + "<br/>";      
	        htmlRespone += "</html>";
	        writer.println(htmlRespone);
	        
	    }

	
	
	
}
