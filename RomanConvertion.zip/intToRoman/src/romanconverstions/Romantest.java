package romanconverstions;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.JUnitCore;
import org.junit.runners.JUnit4;

public class Romantest {

	@Test
	public void testIntToRoman() {
		
		JUnit test = new JUnit();
		String result = test.IntegerToRoman(25);
		assertEquals("XXV", result);
		
	}

}
